import java.util.Scanner;

public class Quickchatapp {
    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in)) {
            Login auth = new Login();
            boolean isRunning = true;
            
            while (isRunning) {
                System.out.println("\n--- MAIN MENU ---");
                System.out.println("1. Register");
                System.out.println("2. Login");
                System.out.println("3. Exit");
                System.out.print("Select an option: ");
                
                String choice = input.nextLine();
                
                switch (choice) {
                    case "1":
                        // --- REGISTRATION ---
                        System.out.print("Enter First Name: ");
                        String fName = input.nextLine();
                        System.out.print("Enter Last Name: ");
                        String lName = input.nextLine();
                        System.out.print("Enter Username: ");
                        String user = input.nextLine();
                        System.out.print("Enter Password: ");
                        String pass = input.nextLine();
                        
                        String regStatus = auth.registerUser(user, pass, fName, lName);
                        System.out.println("\n" + regStatus);
                        
                        if (regStatus.equals("Username and Password successfully captured.")) {
                            // The specific personalized welcome you requested
                            System.out.println("Welcome " + fName + " it's nice to meet you!");
                        }
                        break;
                        
                    case "2":
                        // --- LOGIN ---
                        System.out.print("Enter Username: ");
                        String logUser = input.nextLine();
                        System.out.print("Enter Password: ");
                        String logPass = input.nextLine();
                        
                        boolean success = auth.loginUser(logUser, logPass);
                        System.out.println("\n" + auth.returnLoginStatus(success));
                        break;
                        
                    case "3":
                        // --- EXIT ---
                        System.out.println("Exiting program... Goodbye!");
                        isRunning = false;
                        break;
                        
                    default:
                        System.out.println("Invalid selection. Please try again.");
                }
            }
        }
    }
}